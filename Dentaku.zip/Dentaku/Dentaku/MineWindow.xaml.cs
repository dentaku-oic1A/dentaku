﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Dentaku
{

    /// <summary>
    /// MineWindow.xaml の相互作用ロジック
    /// </summary>
    /// 
    public partial class MineWindow : Window
    {
        public bool[,] bomb = new bool[14, 26];
        public int[,] BombCountTable = new int[14, 26];
        public Button[,] buttons = new Button[14, 26];
        public double BombProbability = 0.3; // ボムの配置確率
        public int BombCount = 0;
        public int BombMaxCount = 100;
        public bool BombMax = false;

        public MineWindow()
        {
            InitializeComponent();
            while (!BombMax)
            {
                for (int i = 0; i < 14; i++)
                {
                    for (int j = 0; j < 26; j++)
                    {
                        bomb[i, j] = BombPut(BombProbability); // 確率でボムを配置
                    }
                }
            }


            for (int i = 0; i < 14; i++)
            {
                for (int j = 0; j < 26; j++)
                {
                    Button button = new Button();
                    button.Name = $"Button{i}_{j}";
                    button.Foreground = Brushes.Black; // ボタンの文字色を黒に設定
                    button.Content = "";
                    button.Width = 30;
                    button.Height = 30;
                    button.Margin = new Thickness(1);
                    button.Click += Button_Click;
                    button.MouseRightButtonDown += MigiClick;
                    Grid.SetRow(button, i);
                    Grid.SetColumn(button, j);
                    GameGrid.Children.Add(button);
                    buttons[i, j] = button; // ボタンを配列に保存
                }

            }
        }
        public bool FirstClickCheck = false; // 最初のクリックかどうかを判定するフラグ
        public bool LastClickCheck = false;  //ゲームオーバー後のクリックを判定するフラグ

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            Button clickedButton = sender as Button;
            // ボタンがクリックされたときの処理
            string buttonName = clickedButton.Name;
            string[] parts = buttonName.Split('_');
            parts[0] = parts[0].Replace("Button", ""); // "Button"を削除
            int row = int.Parse(parts[0]);
            int column = int.Parse(parts[1]);

            if (FirstClickCheck == false)
            {
                FirstClick(row, column); // 最初のクリックの処理
            }

            FirstClickCheck = true; // 最初のクリックが完了したのでフラグを更新

            if (LastClickCheck)
            {
                ResetGame(); // ゲームオーバー後のクリックはゲームをリセット
                LastClickCheck = false; // ゲームオーバー後のクリックフラグをリセット
                return;
            }


            if (bomb[row, column])
            {
                MessageBox.Show("ゲームオーバー");

                for (int i = 0; i < 14; i++)
                {
                    for (int j = 0; j < 26; j++)
                    {
                        if (bomb[i, j])
                        {
                            buttons[i, j].Content = "💣"; // ボムの位置に💣を表示
                            buttons[i, j].Foreground = Brushes.Black; // ボムの文字色を黒に変更
                            buttons[i, j].Background = Brushes.Red; // ボムの背景色を赤に変更
                        }
                        else
                        {
                            buttons[i, j].Content = BombCountTable[i, j]; // ボムがない場所には周囲のボム数を表示
                            buttons[i, j].Foreground = ColorDiside(BombCountTable[i, j]); // ボム数に応じて色を変更
                            buttons[i, j].Background = Brushes.DarkGray; // ボタンの背景色を変更
                        }
                    }
                    LastClickCheck = true;

                }
            }
            else if (BombCountTable[row, column] == 0)
            {
                ZeroClick(row, column); // クリックした場所が0なら周囲のセルも開く
            }
            else
            {

                clickedButton.Content = BombCountTable[row, column];

                clickedButton.Foreground = ColorDiside(BombCountTable[row, column]); // ボム数に応じて色を変更

                clickedButton.Background = Brushes.DarkGray; // ボタンの背景色を変更

            }

            if (ClearCheck())
            {
                MessageBox.Show("クリアしました！"); // 全てのボムがない場所が開かれたらクリア
                ResetGame(); // ゲームをリセット
            }
        }

        public void MigiClick(object sender, MouseButtonEventArgs e)
        {
            Button ClickedButton = sender as Button;
            string buttonName = ClickedButton.Name;
            string[] parts = buttonName.Split('_');
            parts[0] = parts[0].Replace("Button", ""); // "Button"を削除
            int row = int.Parse(parts[0]);
            int column = int.Parse(parts[1]);




            if (ClickedButton.Content == "")
            {
                ClickedButton.Foreground = Brushes.Red; // 右クリックで文字色を黒に設定
                ClickedButton.Content = "🚩"; // 🚩マークを追加
            }
            else if (ClickedButton.Content == "🚩")
            {
                ClickedButton.Foreground = Brushes.Black; // 文字色を黒に戻す
                ClickedButton.Content = ""; // 🚩マークを削除
            }


            if (ClearCheck())
            {
                MessageBox.Show("クリアしました！"); // 全てのボムがない場所が開かれたらクリア
                ResetGame(); // ゲームをリセット
            }
        }
        public bool BombPut(double x)
        {

            Random random = new Random();
            double randomNumber = random.NextDouble();
            if (randomNumber <= x && BombCount < BombMaxCount)
            {
                BombCount++;
                return true; // ボムあり
            }
            else if (BombMaxCount == BombCount)
            {
                BombMax = true; // ボムの最大数に達した場合、フラグを立てる
                return false; // ボムなし
            }
            else
            {
                return false; // ボムなし
            }
        }

        public int CountBombs(int row, int column)
        {
            int count = 0;
            for (int i = -1; i < 2; i++)
            {
                for (int j = -1; j < 2; j++)
                {
                    if (row + i >= 0 && row + i < 14 &&
                        column + j >= 0 && column + j < 26
                        && bomb[row + i, column + j])
                    {
                        count++;
                    }
                }
            }
            return count;
        }
        public void FirstClick(int row, int column)
        {
            bomb[row, column] = false; // 最初のクリックの位置にボムがあった場合、ボムを消す
            for (int i = 0; i < 14; i++)
            {
                for (int j = 0; j < 26; j++)
                {
                    BombCountTable[i, j] = CountBombs(i, j);

                }
            }

            for (int i = -3; i < 4; i++)
            {
                for (int j = -3; j < 4; j++)
                {
                    if (row + i >= 0 && row + i < 14 &&
                        column + j >= 0 && column + j < 26)
                    {
                        if (bomb[row + i, column + j] == false)
                        {
                            if (BombCountTable[row + i, column + j] == 0)
                            {
                                ZeroClick(row + i, column + j); // クリックした場所が0なら周囲のセルも開く
                            }
                            else
                            {
                                buttons[row + i, column + j].Content = BombCountTable[row + i, column + j];
                                buttons[row + i, column + j].Foreground = ColorDiside(BombCountTable[row + i, column + j]); // ボム数に応じて色を変更
                                buttons[row + i, column + j].Background = Brushes.DarkGray; // ボタンの背景色を変更
                            }
                        }// 最初のクリックの周囲のボムを消す
                    }
                }
            }
        }
        public void ZeroClick(int row, int column)
        {
            if (row < 0 || row >= 14 || column < 0 || column >= 26)
            {
                return; // 範囲外のクリックは無視
            }
            if (buttons[row, column].Content != "" || bomb[row, column])
            {
                return; // 既に開かれているボタンやボムの位置は無視
            }
            buttons[row, column].Content = BombCountTable[row, column];
            buttons[row, column].Foreground = ColorDiside(BombCountTable[row, column]); // ボム数に応じて色を変更
            buttons[row, column].Background = Brushes.DarkGray; // ボタンの背景色を変更
            if (BombCountTable[row, column] == 0)
            {
                // 周囲のセルも開く
                for (int i = -1; i <= 1; i++)
                {
                    for (int j = -1; j <= 1; j++)
                    {
                        ZeroClick(row + i, column + j);
                    }
                }
            }
        }

        public bool ClearCheck()
        {
            for (int i = 0; i < 14; i++)
            {
                for (int j = 0; j < 26; j++)
                {
                    if (!bomb[i, j] && (buttons[i, j].Content == "" || buttons[i, j].Content == "🚩") || buttons[i, j].Background == Brushes.Red)
                    {
                        return false; // ボムがない場所でボタンが空ならクリアではない
                    }
                }
            }
            return true; // 全てのボムがない場所が開かれていればクリア
        }

        public void ResetGame()
        {
            // ゲームをリセットする処理
            FirstClickCheck = false; // 最初のクリックフラグをリセット
            BombMax = false; // ボムの最大数フラグをリセット
            BombCount = 0; // ボムのカウントをリセット
            while (!BombMax)
            {
                for (int i = 0; i < 14; i++)
                {
                    for (int j = 0; j < 26; j++)
                    {
                        bomb[i, j] = BombPut(BombProbability); // ボムを再配置
                        buttons[i, j].Content = ""; // ボタンの内容を空にする
                        buttons[i, j].Background = Brushes.LightGray; // ボタンの背景色を初期化
                    }
                }
            }
        }

        public Brush ColorDiside(int count)
        {
            switch (count)
            {
                case 1:
                    return Brushes.Blue;
                case 2:
                    return Brushes.Green;
                case 3:
                    return Brushes.Red;
                case 4:
                    return Brushes.DarkBlue;
                case 5:
                    return Brushes.DarkRed;
                case 6:
                    return Brushes.Cyan;
                case 7:
                    return Brushes.Black;
                case 8:
                    return Brushes.Orange;
                default:
                    return Brushes.Black; // デフォルトの色
            }
        }

    }
}
