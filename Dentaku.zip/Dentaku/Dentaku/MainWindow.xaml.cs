﻿using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Dentaku
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        bool isPeriod = false;
        int kakkoCount = 0;
        int kakusiCount = 0;
        int commaCount = 0;
        public MainWindow()
        {
            InitializeComponent();
            string[] BtnName = {"C","AC","()","÷",
                                "9","8", "7", "×",
                                "6","5", "4", "-",
                                "3","2", "1", "+",
                                "0","00",".", "="};
            int BtnCount = 0;
            for (int i = 1; i <= 5; i++)
            {
                for (int j = 0; j <= 3; j++)
                {
                    Button btn = new Button();
                    btn.Content = BtnName[BtnCount];
                    btn.Name = "Button_" + BtnCount;
                    btn.Click += Btn_Click;
                    btn.Margin = new Thickness(7);
                    btn.FontSize = 20;
                    btn.Background = Brushes.LightGray; //ボタンの色
                    if (j == 3)
                    {
                        btn.Background = Brushes.AliceBlue; //演算子ボタンの色
                    }

                    Grid.SetRow(btn, i);
                    Grid.SetColumn(btn, j);
                    GridMain.Children.Add(btn);

                    BtnCount++;
                }

            }
        }
        private void Btn_Click(object sender, RoutedEventArgs e)
        {
            Button btn = (Button)sender;
            string text = TextBoxInput.Text;
            string last = text.Length > 0 ? text[text.Length - 1].ToString () : "\0";
            switch (btn.Content.ToString())
            {
                case "C":
                    if (text.Length > 0)
                    {
                        if (last == ".") isPeriod = false;
                        if (last == "(") kakkoCount--;
                        if (last == ")") kakkoCount++;
                        TextBoxInput.Text = text.Remove(text.Length - 1, 1);
                    }
                    break;
                case "AC":
                    TextBoxInput.Text = "";
                    isPeriod = false;
                    kakkoCount = 0;
                    break;
                case "()":
                    if (last == ".") break;
                    if (kakkoCount > 0 && (int.TryParse(last, out int c) || last == ")"))
                    {
                        TextBoxInput.Text += ")";
                        kakkoCount--;
                    }
                    else
                    {
                        if (last == ")" || int.TryParse(last, out int d))
                        {
                            TextBoxInput.Text += "×";
                        }
                        TextBoxInput.Text += "(";
                        kakkoCount++;
                    }
                    break;
                case "=":
                    bool isSuuji = false;
                    kakusiCount = 0;
                    if (text.Length == 0 || last == ".") break;
                    isPeriod = false;

                    if (last == "(") return;

                    if (kakkoCount !=0)
                    {
                        while(kakkoCount > 0)
                        {
                            TextBoxInput.Text += ")";
                            kakkoCount--;
                        }
                        return;
                    }
                    isPeriod = false;

                    //ここから
                    foreach (char n in text)
                    {
                        if (int.TryParse(n.ToString(), out int i))
                        {
                            isSuuji = true;
                        }
                    }

                    if (!isSuuji)
                    {
                        MessageBox.Show("正しい式を入力してください");
                        return;
                    }

                    //ここまで式の判定(数字が式に含まれているか)

                    TextBoxInput.Text = Calclate(text);


                    break;
                case ".":
                    if (isPeriod) break;
                    if (int.TryParse(last, out int a))
                    {
                        TextBoxInput.Text += btn.Content.ToString();
                        isPeriod = true;
                    }
                    else if(text.Length > 0)
                    {
                        TextBoxInput.Text = text.Remove(text.Length - 1, 1) + btn.Content.ToString();
                        isPeriod = true;
                    }
                    break;

                case "÷":
                case "×":
                case "+":
                    kakusiCount += 1;
                    if (kakusiCount > 10)
                    {
                        kakusiCount = 0;
                        MineWindow mineWindow = new MineWindow();
                        mineWindow.Show();
                    }
                    if (last == ")" || int.TryParse(last, out int b))
                    {
                        TextBoxInput.Text += btn.Content.ToString();
                    }
                    else if(text.Length > 0 && last != ".")
                    {
                        TextBoxInput.Text = text.Remove(text.Length - 1, 1) + btn.Content.ToString();
                    }
                    isPeriod = false;

                    commaCount = 0;

                    break;
                case "-":
                    if (last == ")" || int.TryParse(last, out int x))
                    {
                        TextBoxInput.Text += btn.Content.ToString();
                    }
                    else if (!int.TryParse(last, out int y))
                    {
                        TextBoxInput.Text += "(-";
                        kakkoCount++;
                    }
                    commaCount = 0;

                    break;

                default:
                    if (last == ")")
                    {
                        TextBoxInput.Text += "×";
                    }
                    
                    TextBoxInput.Text += btn.Content.ToString();
                    break;
            }
        }

        private string Calclate(string input)
        {
            string fusionNumber = "";
            List<string> formula = new List<string>();
            
            //KakkoCalcでかっこをとる
            while (input.Contains('('))
            {
                input = kakkoCalc(input);
            }

            for (int i = 1; i < input.Length; i++)
            {
                if(input[i-1] == '-' && input[i] == '-')
                {
                    input = input.Remove(i - 1,2);
                    input = input.Insert(i-1, "+");
                }
            }

            // 入力文字列を分解してリストに格納
            foreach (char c in input)
            {
                if (int.TryParse(c.ToString(), out int a))
                {
                    fusionNumber += c;
                }
                else if (c == '.')
                {
                    fusionNumber += c;
                }
                else if (c == '-')
                {
                    if (fusionNumber.Length == 0)
                    {
                        fusionNumber += "-";
                    }
                    else
                    {
                        formula.Add(fusionNumber);
                        fusionNumber = "-";
                        formula.Add("+");
                    }
                }
                else
                {
                    if (fusionNumber.Length != 0) formula.Add(fusionNumber);
                    fusionNumber = "";
                    formula.Add(c.ToString());
                }
            }

            if (fusionNumber != "") formula.Add(fusionNumber);

            //掛け算と割り算の処理
            for (int i = 0; i < formula.Count; i++)
            {
                if (formula[i] == "×" || formula[i] == "÷")
                {
                    double left = double.Parse(formula[i - 1]);
                    double right = double.Parse(formula[i + 1]);
                    double result = formula[i] == "×" ? left * right : left / right;
                    formula[i - 1] = result.ToString();
                    formula.RemoveAt(i); //演算子削除
                    formula.RemoveAt(i); //右オペランド削除
                    i--; //インデックスを戻す
                }
            }

            //足し算と引き算の処理
            for (int i = 0; i < formula.Count; i++)
            {
                if (formula[i] == "+" || formula[i] == "-")
                {

                    double left = double.Parse(formula[i - 1]);
                    double right = double.Parse(formula[i + 1]);
                    double result = formula[i] == "+" ? left + right : left - right;
                    formula[i - 1] = result.ToString();
                    formula.RemoveAt(i); //演算子削除
                    formula.RemoveAt(i); //右オペランド削除
                    i--; //インデックスを戻す
                }
            }


            //小数点の管理
            //答えに小数点が含まれるかどうかを判定
            if (formula[0].Contains('.'))
            {
                isPeriod = true;
            }

            while (formula[0].EndsWith("0") && isPeriod)
            {
                formula[0] = formula[0].Remove(formula[0].Length - 1, 1);
            }

            if (formula[0].EndsWith("."))
            {
                formula[0] = formula[0].Remove(formula[0].Length - 1, 1);
                isPeriod = false;
            }

            return formula[0];
        }

        private string kakkoCalc(string input)
        {
            int kakkoCount = 0;
            string Kakkononaka = string.Empty;
            bool isKakko = false;
            for (int i = 0; i < input.Length; i++)
            {
                if (input[i] == '(')
                {
                    kakkoCount++;
                    isKakko = true;
                }
                if (input[i] == ')')
                {
                    kakkoCount--;
                }

                if (kakkoCount == 0 && isKakko)
                {
                    //Kakkomojisuは、かっこの中の文字数
                    int Kakkomojisu = i - input.IndexOf('(')-1;

                    //かっこを"含まない"、かっこの中の式をKakkononakaに入れる
                    Kakkononaka = input.Substring(input.IndexOf('(') + 1, Kakkomojisu);

                    //かっこの中の部分を!に置き換える Kakkomojisuに2を足すのは、(、）の文字を含めて置き換えるため
                    input = input.Replace(input.Substring(input.IndexOf('('), Kakkomojisu+2), "!");

                    //置き換えた!に、Kakkononakaを計算した答えをもう一度置き換える。
                    input = input.Replace("!", Calclate(Kakkononaka));

                    isKakko = false;
                    return input ;
                }
            }
            return input;
        }
    }
}