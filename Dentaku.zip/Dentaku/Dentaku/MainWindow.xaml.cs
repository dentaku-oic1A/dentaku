﻿using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Dentaku
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        bool isPeriod = false;
        int kakkoCount = 0;
        int kakusiCount = 0;
        public MainWindow()
        {
            InitializeComponent();
            string[] BtnName = {"C","AC","()","÷",
                                "9","8", "7", "×",
                                "6","5", "4", "-",
                                "3","2", "1", "+",
                                "0","00",".", "="};
            int BtnCount = 0;
            for (int i = 1; i <= 5; i++)
            {
                for (int j = 0; j <= 3; j++)
                {
                    Button btn = new Button();
                    btn.Content = BtnName[BtnCount];
                    btn.Name = "Button_" + BtnCount;
                    btn.Click += Btn_Click;
                    btn.Margin = new Thickness(7);
                    btn.FontSize = 20;
                    btn.Background = Brushes.LightGray; //ボタンの色
                    if (j == 3)
                    {
                        btn.Background = Brushes.AliceBlue; //演算子ボタンの色
                    }

                    Grid.SetRow(btn, i);
                    Grid.SetColumn(btn, j);
                    GridMain.Children.Add(btn);

                    BtnCount++;
                }

            }
        }
        private void Btn_Click(object sender, RoutedEventArgs e)
        {
            Button btn = (Button)sender;
            string text = TextBoxInput.Text;
            string last = text.Length > 0 ? text[text.Length - 1].ToString () : "\0";
            switch (btn.Content.ToString())
            {
                case "C":
                    if (text.Length > 0)
                    {
                        if (last == ".") isPeriod = false;
                        if (last == "(") kakkoCount--;
                        if (last == ")") kakkoCount++;
                        TextBoxInput.Text = text.Remove(text.Length - 1, 1);
                    }
                    break;
                case "AC":
                    TextBoxInput.Text = "";
                    isPeriod = false;
                    kakkoCount = 0;
                    break;
                case "()":
                    if (last == ".") break;
                    if (kakkoCount > 0 && (int.TryParse(last, out int c) || last == ")"))
                    {
                        TextBoxInput.Text += ")";
                        kakkoCount--;
                    }
                    else
                    {
                        TextBoxInput.Text += "(";
                        kakkoCount++;
                    }
                    break;
                case "=":
                    if (text.Length == 0 || last == ".") break;
                    isPeriod = false;
                    TextBoxInput.Text = Calclate(text);
                    break;
                case ".":
                    if (isPeriod) break;
                    if (int.TryParse(last, out int a))
                    {
                        TextBoxInput.Text += btn.Content.ToString();
                        isPeriod = true;
                    }
                    else if(text.Length > 0)
                    {
                        TextBoxInput.Text = text.Remove(text.Length - 1, 1) + btn.Content.ToString();
                        isPeriod = true;
                    }
                    break;

                case "÷":
                case "×":
                case "-":
                case "+":
                    kakusiCount += 1;
                    if (kakusiCount > 10)
                    {
                        kakusiCount = 0;
                        MineWindow mineWindow = new MineWindow();
                        mineWindow.Show();
                    }
                    if (last == ")" || int.TryParse(last, out int b))
                    {
                        TextBoxInput.Text += btn.Content.ToString();
                    }
                    else if(text.Length > 0 && last != ".")
                    {
                        TextBoxInput.Text = text.Remove(text.Length - 1, 1) + btn.Content.ToString();
                    }
                    isPeriod = false;
                    break;
                default:
                    if (last == ")")
                    {
                        TextBoxInput.Text += "×";
                    }
                    TextBoxInput.Text += btn.Content.ToString();
                    Console.Beep(130,10);
                    
                    break;
            }
        }

        private string Calclate(string input)
        {

            string fusionNumber = "";
            List<string> formula = new List<string>();
            //input += "=";
            //KakkoCalcでかっこをとる
            while (input.Contains('('))
            {
                input = kakkoCalc(input);
            }
            // 入力文字列を分解してリストに格納
            foreach (char c in input)
            {
                if (int.TryParse(c.ToString(), out int a))
                {
                    fusionNumber += c;
                }
                else if (c == '.')
                {
                    fusionNumber += c;
                }
                else
                {
                    if (fusionNumber.Length != 0) formula.Add(fusionNumber);
                    fusionNumber = "";
                    formula.Add(c.ToString());
                }
            }

            if (fusionNumber != "") formula.Add(fusionNumber);



            //掛け算と割り算の処理
            for (int i = 0; i < formula.Count; i++)
            {
                if (formula[i] == "×" || formula[i] == "÷")
                {
                    double left = double.Parse(formula[i - 1]);
                    double right = double.Parse(formula[i + 1]);
                    double result = formula[i] == "×" ? left * right : left / right;
                    formula[i - 1] = result.ToString();
                    formula.RemoveAt(i); //演算子削除
                    formula.RemoveAt(i); //右オペランド削除
                    i--; //インデックスを戻す
                }
            }

            //足し算と引き算の処理
            for (int i = 0; i < formula.Count; i++)
            {
                if (formula[i] == "+" || formula[i] == "-")
                {
                    double left = double.Parse(formula[i - 1]);
                    double right = double.Parse(formula[i + 1]);
                    double result = formula[i] == "+" ? left + right : left - right;
                    formula[i - 1] = result.ToString();
                    formula.RemoveAt(i); //演算子削除
                    formula.RemoveAt(i); //右オペランド削除
                    i--; //インデックスを戻す
                }
            }


            //小数点の管理
            //答えに小数点が含まれるかどうかを判定
            if (formula[0].Contains('.'))
            {
                isPeriod = true;
            }

            while (formula[0].EndsWith("0") && isPeriod)
            {
                formula[0] = formula[0].Remove(formula[0].Length - 1, 1);
            }

            if (formula[0].EndsWith("."))
            {
                formula[0] = formula[0].Remove(formula[0].Length - 1, 1);
                isPeriod = false;
            }

            return formula[0];
        }

        private string kakkoCalc(string input)
        {
            int kakkoCount = 0;
            string Kakkononaka = string.Empty;
            bool isKakko = false;
            //かっこの中を取り出して、計算したものに置き換える
            for (int i = 0; i < input.Length; i++)
            {
                if (input[i] == '(')
                {
                    kakkoCount++;
                    isKakko = true;
                }
                if (input[i] == ')')
                {
                    kakkoCount--;
                }

                if (kakkoCount == 0 && isKakko)
                {
                    int tojikakko = i - input.IndexOf('(')-1;
                    Kakkononaka = input.Substring(input.IndexOf('(') + 1, tojikakko);
                    input = input.Replace(input.Substring(input.IndexOf('('), tojikakko+2), "!");//かっこの中の部分を!に置き換える

                    input = input.Replace("!", Calclate(Kakkononaka));

                    isKakko = false;
                    return input ;
                }
            }
            return input;




            //string Kakkononaka = input.Substring(input.IndexOf('('), input.LastIndexOf(')'));
            //input = input.Replace(Kakkononaka, Calclate(Kakkononaka));




        }
    }
}